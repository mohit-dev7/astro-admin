export class UserData {

    id: number;
    name: string;
    email: string;
    password: string;
}
