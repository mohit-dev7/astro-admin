import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tbl-bootstrap',
  templateUrl: './tbl-bootstrap.component.html',
  styleUrls: ['./tbl-bootstrap.component.scss']
})
export class TblBootstrapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
